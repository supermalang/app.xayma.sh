# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools, _

class pos_config(models.Model):
    _inherit = 'pos.config' 

    allow_kitchens_receipt = fields.Boolean('Allow Kitchen Receipt', default=True)

