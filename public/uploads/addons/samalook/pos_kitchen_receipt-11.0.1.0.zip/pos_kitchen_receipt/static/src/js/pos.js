odoo.define('pos_kitchen_receipt.pos_kitchen_receipt', function(require){
    var screens = require('point_of_sale.screens');
    var core = require('web.core');
    var gui = require('point_of_sale.gui');
    var models = require('point_of_sale.models');
    var QWeb = core.qweb;

    var KitchenReceiptScreenWidget = screens.ReceiptScreenWidget.extend({
        template: 'KitchenReceiptScreenWidget',
        click_next: function(){
            this.gui.show_screen('products');
        },
        click_back: function(){
            this.gui.show_screen('products');
        },
        render_receipt: function(){
            self = this;
            var order = self.pos.get_order();
            self.$('.pos-receipt-container').html(order.receipt_val);
            order.receipt_val = "";
        },
        print_web: function(){
            window.print();
        },
    });

    gui.define_screen({name:'kitchen-receipt', widget: KitchenReceiptScreenWidget});

    var _super_order = models.Order.prototype;
    models.Order = models.Order.extend({
        printChanges2: function(){
            var printers = this.pos.printers;
            var receipt = "";
            for(var i = 0; i < printers.length; i++){
                var changes = this.computeChanges(printers[i].config.product_categories_ids);
                if ( changes['new'].length > 0 || changes['cancelled'].length > 0){
                    receipt += QWeb.render('KitchenOrderChangeReceipt',{changes:changes, widget:this});
                }
            }
            var order = this.pos.get_order();
            order.receipt_val = receipt;
            this.pos.gui.show_screen('kitchen-receipt');
        },
    });

    var WVPosKitchenReceiptButton = screens.ActionButtonWidget.extend({
        template: 'WVPosKitchenReceiptButton',

        button_click: function(){
            var order = this.pos.get_order();
            if(order.hasChangesToPrint()){
                order.printChanges2();
                order.saveChanges();
            }
        },  
        
    });

    screens.define_action_button({
        'name': 'Kitchen Receipt',
        'widget': WVPosKitchenReceiptButton,
        'condition': function(){
            return this.pos.config.allow_kitchens_receipt;
        },
    });




});
