# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
import logging
from datetime import timedelta
from functools import partial

import psycopg2
import pytz

from odoo import api, fields, models, tools, _
from odoo.tools import float_is_zero
from odoo.exceptions import UserError
from odoo.http import request
import odoo.addons.decimal_precision as dp

_logger = logging.getLogger(__name__)


class PosConfiguration(models.Model):
	_inherit = 'pos.config'
	
	discount_type = fields.Selection([('percentage', "Percentage"), ('fixed', "Fixed")], string='Discount Type', default='percentage', help='Seller can apply different Discount Type in POS.')
	
class PosOrder(models.Model):
	_inherit = 'pos.order'

	discount_type = fields.Char(string='Discount Type')

	def _prepare_invoice(self):
		invoice_type = 'out_invoice' if self.amount_total >= 0 else 'out_refund'
		return {
			'name': self.name,
			'origin': self.name,
			'account_id': self.partner_id.property_account_receivable_id.id,
			'journal_id': self.session_id.config_id.invoice_journal_id.id,
			'company_id': self.company_id.id,
			'type': invoice_type,
			'reference': self.name,
			'partner_id': self.partner_id.id,
			'comment': self.note or '',
			'pos_order_id' : self.id,
			# considering partner's sale pricelist's currency
			'currency_id': self.pricelist_id.currency_id.id,
			'user_id': self.user_id.id,
		}

	@api.model
	def _amount_line_tax(self, line, fiscal_position_id):
		taxes = line.tax_ids.filtered(lambda t: t.company_id.id == line.order_id.company_id.id)
		if fiscal_position_id:
			taxes = fiscal_position_id.map_tax(taxes, line.product_id, line.order_id.partner_id)
		for order in self:
			if line.discount_line_type == 'Percentage':
				price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)

			else:
				price = line.price_unit - line.discount

		taxes = taxes.compute_all(price, line.order_id.pricelist_id.currency_id, line.qty, product=line.product_id, partner=line.order_id.partner_id or False)['taxes']
		return sum(tax.get('amount', 0.0) for tax in taxes)


	@api.depends('statement_ids', 'lines.price_subtotal_incl', 'lines.discount')
	def _compute_amount_all(self):
		for order in self:
			order.amount_paid = order.amount_return = order.amount_tax = 0.0
			currency = order.pricelist_id.currency_id
			order.amount_paid = sum(payment.amount for payment in order.statement_ids)
			order.amount_return = sum(payment.amount < 0 and payment.amount or 0 for payment in order.statement_ids)
			order.amount_tax = currency.round(sum(self._amount_line_tax(line, order.fiscal_position_id) for line in order.lines))
			amount_untaxed = currency.round(sum(line.price_subtotal for line in order.lines))
			order.amount_total = order.amount_paid

	@api.model
	def create_from_ui(self, orders):
		# Keep only new orders
		submitted_references = [o['data']['name'] for o in orders]
		pos_order = self.search([('pos_reference', 'in', submitted_references)])
		existing_orders = pos_order.read(['pos_reference'])
		existing_references = set([o['pos_reference'] for o in existing_orders])
		orders_to_save = [o for o in orders if o['data']['name'] not in existing_references]
		order_ids = []

		for tmp_order in orders_to_save:
			to_invoice = tmp_order['to_invoice']
			order = tmp_order['data']
			if to_invoice:
				self._match_payment_to_invoice(order)
			pos_order = self._process_order(order)
			order_ids.append(pos_order.id)

			for order_id in order_ids:
				pos_order_id = self.browse(order_id)
				if pos_order_id:
					ref_order = [o['data'] for o in orders if o['data'].get('name') == pos_order_id.pos_reference]
					for order in ref_order:
						if pos_order_id.session_id.config_id.discount_type == 'percentage':
							pos_order_id.update({'discount_type': "Percentage"})
							pos_order_id.lines.update({'discount_line_type': "Percentage"})
						if pos_order_id.session_id.config_id.discount_type == 'fixed':
							pos_order_id.update({'discount_type': "Fixed"})
							pos_order_id.lines.update({'discount_line_type': "Fixed"})
						
			try:
				pos_order.action_pos_order_paid()
			except psycopg2.OperationalError:
				# do not hide transactional errors, the order(s) won't be saved!
				raise
			except Exception as e:
				_logger.error('Could not fully process the POS Order: %s', tools.ustr(e))

			if to_invoice:
				pos_order.action_pos_order_invoice()
				pos_order.invoice_id.sudo().action_invoice_open()
				pos_order.account_move = pos_order.invoice_id.move_id
		return order_ids

	def _action_create_invoice_line(self, line=False, invoice_id=False):
		InvoiceLine = self.env['account.invoice.line']
		inv_name = line.product_id.name_get()[0][1]
		inv_line = {
			'invoice_id': invoice_id,
			'product_id': line.product_id.id,
			'quantity': line.qty,
			'account_analytic_id': self._prepare_analytic_account(line),
			'name': inv_name,
			'pos_order_id' : self.id,
		}
		# Oldlin trick
		invoice_line = InvoiceLine.sudo().new(inv_line)
		invoice_line._onchange_product_id()
		invoice_line.invoice_line_tax_ids = invoice_line.invoice_line_tax_ids.filtered(lambda t: t.company_id.id == line.order_id.company_id.id).ids
		fiscal_position_id = line.order_id.fiscal_position_id
		if fiscal_position_id:
			invoice_line.invoice_line_tax_ids = fiscal_position_id.map_tax(invoice_line.invoice_line_tax_ids, line.product_id, line.order_id.partner_id)
		invoice_line.invoice_line_tax_ids = invoice_line.invoice_line_tax_ids.ids
		# We convert a new id object back to a dictionary to write to
		# bridge between old and new api
		inv_line = invoice_line._convert_to_write({name: invoice_line[name] for name in invoice_line._cache})
		inv_line.update(price_unit=line.price_unit, discount=line.discount)
		return InvoiceLine.sudo().create(inv_line)

	def _prepare_account_move_and_lines(self, session=None, move=None):
		def _flatten_tax_and_children(taxes, group_done=None):
			children = self.env['account.tax']
			if group_done is None:
				group_done = set()
			for tax in taxes.filtered(lambda t: t.amount_type == 'group'):
				if tax.id not in group_done:
					group_done.add(tax.id)
					children |= _flatten_tax_and_children(tax.children_tax_ids, group_done)
			return taxes + children

		# Tricky, via the workflow, we only have one id in the ids variable
		"""Create a account move line of order grouped by products or not."""
		IrProperty = self.env['ir.property']
		ResPartner = self.env['res.partner']

		if session and not all(session.id == order.session_id.id for order in self):
			raise UserError(_('Selected orders do not have the same session!'))

		grouped_data = {}
		have_to_group_by = session and session.config_id.group_by or False
		rounding_method = session and session.config_id.company_id.tax_calculation_rounding_method



		def add_anglosaxon_lines(grouped_data):
			Product = self.env['product.product']
			Analytic = self.env['account.analytic.account']
			for product_key in list(grouped_data.keys()):
				if product_key[0] == "product":
					line = grouped_data[product_key][0]
					product = Product.browse(line['product_id'])
					# In the SO part, the entries will be inverted by function compute_invoice_totals
					price_unit = self._get_pos_anglo_saxon_price_unit(product, line['partner_id'], line['quantity'])
					account_analytic = Analytic.browse(line.get('analytic_account_id'))
					res = Product._anglo_saxon_sale_move_lines(
						line['name'], product, product.uom_id, line['quantity'], price_unit,
							fiscal_position=order.fiscal_position_id,
							account_analytic=account_analytic)
					if res:
						line1, line2 = res
						line1 = Product._convert_prepared_anglosaxon_line(line1, order.partner_id)
						insert_data('counter_part', {
							'name': line1['name'],
							'account_id': line1['account_id'],
							'credit': line1['credit'] or 0.0,
							'debit': line1['debit'] or 0.0,
							'partner_id': line1['partner_id']

						})

						line2 = Product._convert_prepared_anglosaxon_line(line2, order.partner_id)
						insert_data('counter_part', {
							'name': line2['name'],
							'account_id': line2['account_id'],
							'credit': line2['credit'] or 0.0,
							'debit': line2['debit'] or 0.0,
							'partner_id': line2['partner_id']
						})

		for order in self.filtered(lambda o: not o.account_move or o.state == 'paid'):
			current_company = order.sale_journal.company_id
			account_def = IrProperty.get(
				'property_account_receivable_id', 'res.partner')
			order_account = order.partner_id.property_account_receivable_id.id or account_def and account_def.id
			partner_id = ResPartner._find_accounting_partner(order.partner_id).id or False
			if move is None:
				# Create an entry for the sale
				journal_id = self.env['ir.config_parameter'].sudo().get_param(
					'pos.closing.journal_id_%s' % current_company.id, default=order.sale_journal.id)
				move = self._create_account_move(
					order.session_id.start_at, order.name, int(journal_id), order.company_id.id)

			def insert_data(data_type, values):
				# if have_to_group_by:
				values.update({
					'partner_id': partner_id,
					'move_id': move.id,
				})

				key = self._get_account_move_line_group_data_type_key(data_type, values, {'rounding_method': rounding_method})
				if not key:
					return

				grouped_data.setdefault(key, [])

				if have_to_group_by:
					if not grouped_data[key]:
						grouped_data[key].append(values)
					else:
						current_value = grouped_data[key][0]
						current_value['quantity'] = current_value.get('quantity', 0.0) + values.get('quantity', 0.0)
						current_value['credit'] = current_value.get('credit', 0.0) + values.get('credit', 0.0)
						current_value['debit'] = current_value.get('debit', 0.0) + values.get('debit', 0.0)
						if 'currency_id' in values:
							current_value['amount_currency'] = current_value.get('amount_currency', 0.0) + values.get('amount_currency', 0.0)
						if key[0] == 'tax' and rounding_method == 'round_globally':
							if current_value['debit'] - current_value['credit'] > 0:
								current_value['debit'] = current_value['debit'] - current_value['credit']
								current_value['credit'] = 0
							else:
								current_value['credit'] = current_value['credit'] - current_value['debit']
								current_value['debit'] = 0

				else:
					grouped_data[key].append(values)

			# because of the weird way the pos order is written, we need to make sure there is at least one line,
			# because just after the 'for' loop there are references to 'line' and 'income_account' variables (that
			# are set inside the for loop)
			# TOFIX: a deep refactoring of this method (and class!) is needed
			# in order to get rid of this stupid hack
			assert order.lines, _('The POS order must have lines when calling this method')
			# Create an move for each order line
			cur = order.pricelist_id.currency_id
			cur_company = order.company_id.currency_id
			amount_cur_company = 0.0
			date_order = (order.date_order or fields.Datetime.now())[:10]
			move_lines = []
			for line in order.lines:
				if cur != cur_company:
					amount_subtotal = cur.with_context(date=date_order).compute(line.price_subtotal, cur_company)
				else:
					amount_subtotal = line.price_subtotal

				# Search for the income account
				if line.product_id.property_account_income_id.id:
					income_account = line.product_id.property_account_income_id.id
				elif line.product_id.categ_id.property_account_income_categ_id.id:
					income_account = line.product_id.categ_id.property_account_income_categ_id.id
				else:
					raise UserError(_('Please define income '
									  'account for this product: "%s" (id:%d).')
									% (line.product_id.name, line.product_id.id))

				name = line.product_id.name
				if line.notice:
					# add discount reason in move
					name = name + ' (' + line.notice + ')'

				# Create a move for the line for the order line
				# Just like for invoices, a group of taxes must be present on this base line
				# As well as its children
				base_line_tax_ids = _flatten_tax_and_children(line.tax_ids_after_fiscal_position).filtered(lambda tax: tax.type_tax_use in ['sale', 'none'])
				data = {
					'name': name,
					'quantity': line.qty,
					'product_id': line.product_id.id,
					'account_id': income_account,
					'analytic_account_id': self._prepare_analytic_account(line),
					'credit': ((amount_subtotal > 0) and amount_subtotal) or 0.0,
					'debit': ((amount_subtotal < 0) and -amount_subtotal) or 0.0,
					'tax_ids': [(6, 0, base_line_tax_ids.ids)],
					'partner_id': partner_id
				}
				if cur != cur_company:
					data['currency_id'] = cur.id
					data['amount_currency'] = -abs(line.price_subtotal) if data.get('credit') else abs(line.price_subtotal)
					amount_cur_company += data['credit'] - data['debit']
				insert_data('product', data)
				move_lines.append({'data_type': 'product', 'values': data})

				# Create the tax lines
				taxes = line.tax_ids_after_fiscal_position.filtered(lambda t: t.company_id.id == current_company.id)
				if not taxes:
					continue
				if line.discount_line_type == 'Percentage':
					price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
				else:
					price = line.price_unit - line.discount
				for tax in taxes.compute_all(price, cur, line.qty)['taxes']:
					if cur != cur_company:
						round_tax = False if rounding_method == 'round_globally' else True
						amount_tax = cur.with_context(date=date_order).compute(tax['amount'], cur_company, round=round_tax)
					else:
						amount_tax = tax['amount']
					data = {
						'name': _('Tax') + ' ' + tax['name'],
						'product_id': line.product_id.id,
						'quantity': line.qty,
						'account_id': tax['account_id'] or income_account,
						'credit': ((amount_tax > 0) and amount_tax) or 0.0,
						'debit': ((amount_tax < 0) and -amount_tax) or 0.0,
						'tax_line_id': tax['id'],
						'partner_id': partner_id,
						'order_id': order.id
					}
					if cur != cur_company:
						data['currency_id'] = cur.id
						data['amount_currency'] = -abs(tax['amount']) if data.get('credit') else abs(tax['amount'])
						amount_cur_company += data['credit'] - data['debit']
					insert_data('tax', data)
					move_lines.append({'data_type': 'tax', 'values': data})
			# round tax lines per order
			if rounding_method == 'round_globally':
				for group_key, group_value in grouped_data.items():
					if group_key[0] == 'tax':
						for line in group_value:
							line['credit'] = cur_company.round(line['credit'])
							line['debit'] = cur_company.round(line['debit'])
							if line.get('currency_id'):
								line['amount_currency'] = cur.round(line.get('amount_currency', 0.0))

			receivable_amounts = order._get_amount_receivable(move_lines)

			data = {
				'name': _("Trade Receivables"),  # order.name,
				'account_id': order_account,
				'credit': ((receivable_amounts['amount'] < 0) and -receivable_amounts['amount']) or 0.0,
				'debit': ((receivable_amounts['amount'] > 0) and receivable_amounts['amount']) or 0.0,
				'partner_id': partner_id
			}
			if receivable_amounts['amount_currency']:
				data['currency_id'] = cur.id
				data['amount_currency'] = -abs(receivable_amounts['amount_currency']) if data.get('credit') else abs(receivable_amounts['amount_currency'])
			insert_data('counter_part', data)

			order.write({'state': 'done', 'account_move': move.id})

		if self and order.company_id.anglo_saxon_accounting:
			add_anglosaxon_lines(grouped_data)

		return {
			'grouped_data': grouped_data,
			'move': move,
		}



class PosOrderLine(models.Model):
	_inherit = 'pos.order.line'

	discount_line_type = fields.Char(string='Discount Type',readonly=True)

	@api.depends('price_unit', 'tax_ids', 'qty', 'discount', 'product_id')
	def _compute_amount_line_all(self):

		for line in self:

			fpos = line.order_id.fiscal_position_id
			tax_ids_after_fiscal_position = fpos.map_tax(line.tax_ids, line.product_id, line.order_id.partner_id) if fpos else line.tax_ids
			
			if line.discount_line_type == "Fixed":
				price = line.price_unit - line.discount

			else:
				price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
			taxes = tax_ids_after_fiscal_position.compute_all(price, line.order_id.pricelist_id.currency_id, line.qty, product=line.product_id, partner=line.order_id.partner_id)

			line.update({
			'price_subtotal_incl': taxes['total_included'],
			'price_subtotal': taxes['total_excluded'],
			})

	
class ReportSaleDetailsInherit(models.AbstractModel):

	_inherit = 'report.point_of_sale.report_saledetails'

	@api.model
	def get_sale_details(self, date_start=False, date_stop=False, configs=False):
		""" Serialise the orders of the day information

		params: date_start, date_stop string representing the datetime of order
		"""
		if not configs:
			configs = self.env['pos.config'].search([])

		user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz or 'UTC')
		today = user_tz.localize(fields.Datetime.from_string(fields.Date.context_today(self)))
		today = today.astimezone(pytz.timezone('UTC'))
		if date_start:
			date_start = fields.Datetime.from_string(date_start)
		else:
			# start by default today 00:00:00
			date_start = today

		if date_stop:
			# set time to 23:59:59
			date_stop = fields.Datetime.from_string(date_stop)
		else:
			# stop by default today 23:59:59
			date_stop = today + timedelta(days=1, seconds=-1)

		# avoid a date_stop smaller than date_start
		date_stop = max(date_stop, date_start)

		date_start = fields.Datetime.to_string(date_start)
		date_stop = fields.Datetime.to_string(date_stop)

		orders = self.env['pos.order'].search([
			('date_order', '>=', date_start),
			('date_order', '<=', date_stop),
			('state', 'in', ['paid','invoiced','done']),
			('config_id', 'in', configs.ids)])

		user_currency = self.env.user.company_id.currency_id

		total = 0.0
		products_sold = {}
		taxes = {}
		for order in orders:
			if user_currency != order.pricelist_id.currency_id:
				total += order.pricelist_id.currency_id.compute(order.amount_total, user_currency)
			else:
				total += order.amount_total
			currency = order.session_id.currency_id

			for line in order.lines:
				key = (line.product_id, line.price_unit, line.discount,line.discount_line_type)
				products_sold.setdefault(key, 0.0)
				products_sold[key] += line.qty

				if line.tax_ids_after_fiscal_position:
					line_taxes = line.tax_ids_after_fiscal_position.compute_all(line.price_unit * (1-(line.discount or 0.0)/100.0), currency, line.qty, product=line.product_id, partner=line.order_id.partner_id or False)
					for tax in line_taxes['taxes']:
						taxes.setdefault(tax['id'], {'name': tax['name'], 'tax_amount':0.0, 'base_amount':0.0})
						taxes[tax['id']]['tax_amount'] += tax['amount']
						taxes[tax['id']]['base_amount'] += tax['base']
				else:
					taxes.setdefault(0, {'name': _('No Taxes'), 'tax_amount':0.0, 'base_amount':0.0})
					taxes[0]['base_amount'] += line.price_subtotal_incl

		st_line_ids = self.env["account.bank.statement.line"].search([('pos_statement_id', 'in', orders.ids)]).ids
		if st_line_ids:
			self.env.cr.execute("""
				SELECT aj.name, sum(amount) total
				FROM account_bank_statement_line AS absl,
					 account_bank_statement AS abs,
					 account_journal AS aj 
				WHERE absl.statement_id = abs.id
					AND abs.journal_id = aj.id 
					AND absl.id IN %s 
				GROUP BY aj.name
			""", (tuple(st_line_ids),))
			payments = self.env.cr.dictfetchall()
		else:
			payments = []

		return {
			'currency_precision': user_currency.decimal_places,
			'total_paid': user_currency.round(total),
			'payments': payments,
			'company_name': self.env.user.company_id.name,
			'taxes': list(taxes.values()),
			'products': sorted([{
				'product_id': product.id,
				'product_name': product.name,
				'code': product.default_code,
				'quantity': qty,
				'discount_line_type': discount_line_type,
				'price_unit': price_unit,
				'discount': discount,
				'uom': product.uom_id.name
			} for (product, price_unit, discount,discount_line_type), qty in products_sold.items()], key=lambda l: l['product_name'])
		}




# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:    
