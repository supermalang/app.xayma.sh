# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
import logging
from datetime import timedelta
from functools import partial

import psycopg2
import pytz

from odoo import api, fields, models, tools, _
from odoo.tools import float_is_zero
from odoo.exceptions import UserError
from odoo.http import request
import odoo.addons.decimal_precision as dp
from functools import partial


_logger = logging.getLogger(__name__)

class AccountInvoiceInherit(models.Model):
	_inherit = "account.invoice"

	pos_order_id = fields.Many2one('pos.order',string="POS order")

	@api.multi
	def get_taxes_values(self):
		tax_grouped = {}
		round_curr = self.currency_id.round
		for line in self.invoice_line_ids:
			price_unit = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
			if line.pos_order_id.discount_type  == "Fixed":
				price_unit = line.price_unit  - line.discount 
			taxes = line.invoice_line_tax_ids.compute_all(price_unit, self.currency_id, line.quantity, line.product_id, self.partner_id)['taxes']
			for tax in taxes:
				val = self._prepare_tax_line_vals(line, tax)
				key = self.env['account.tax'].browse(tax['id']).get_grouping_key(val)

				if key not in tax_grouped:
					tax_grouped[key] = val
					tax_grouped[key]['base'] = round_curr(val['base'])
				else:
					tax_grouped[key]['amount'] += val['amount']
					tax_grouped[key]['base'] += round_curr(val['base'])
		return tax_grouped



class AccountInvoiceLineInherit(models.Model):
	_inherit = "account.invoice.line"

	pos_order_id = fields.Many2one('pos.order',string="POS order")

	@api.one
	@api.depends('price_unit', 'discount', 'invoice_line_tax_ids', 'quantity',
		'product_id', 'invoice_id.partner_id', 'invoice_id.currency_id', 'invoice_id.company_id',
		'invoice_id.date_invoice', 'invoice_id.date')
	def _compute_price(self):
		for i in self:
			currency = i.invoice_id and i.invoice_id.currency_id or None
			if i.pos_order_id.discount_type  == "Fixed":
				price = i.price_unit - i.discount
			else:
				price = i.price_unit * (1 - (i.discount or 0.0) / 100.0)
			taxes = False
			if i.invoice_line_tax_ids:
				taxes = i.invoice_line_tax_ids.compute_all(price, currency, i.quantity, product=i.product_id, partner=i.invoice_id.partner_id)
			i.price_subtotal = price_subtotal_signed = taxes['total_excluded'] if taxes else i.quantity * price
			i.price_total = taxes['total_included'] if taxes else i.price_subtotal
			if i.invoice_id.currency_id and i.invoice_id.company_id and i.invoice_id.currency_id != i.invoice_id.company_id.currency_id:
				price_subtotal_signed = i.invoice_id.currency_id.with_context(date=i.invoice_id._get_currency_rate_date()).compute(price_subtotal_signed, i.invoice_id.company_id.currency_id)
			sign = i.invoice_id.type in ['in_refund', 'out_refund'] and -1 or 1
			i.price_subtotal_signed = price_subtotal_signed * sign
			
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:   